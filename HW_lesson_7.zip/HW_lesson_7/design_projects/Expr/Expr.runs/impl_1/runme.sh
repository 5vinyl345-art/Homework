#!/bin/bash

# 
# Vivado(TM)
# runme.sh: a Vivado-generated Runs Script for UNIX
# Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
# Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
# 

echo "This script was generated under a different operating system."
echo "Please update the PATH and LD_LIBRARY_PATH variables below, before executing this script"
exit

if [ -z "$PATH" ]; then
  PATH=F:/AMD_Design_Tools/2026.1/Vitis/bin;F:/AMD_Design_Tools/2026.1/Vivado/ids_lite/ISE/bin/nt64;F:/AMD_Design_Tools/2026.1/Vivado/ids_lite/ISE/lib/nt64:F:/AMD_Design_Tools/2026.1/Vivado/bin
else
  PATH=F:/AMD_Design_Tools/2026.1/Vitis/bin;F:/AMD_Design_Tools/2026.1/Vivado/ids_lite/ISE/bin/nt64;F:/AMD_Design_Tools/2026.1/Vivado/ids_lite/ISE/lib/nt64:F:/AMD_Design_Tools/2026.1/Vivado/bin:$PATH
fi
export PATH

if [ -z "$LD_LIBRARY_PATH" ]; then
  LD_LIBRARY_PATH=
else
  LD_LIBRARY_PATH=:$LD_LIBRARY_PATH
fi
export LD_LIBRARY_PATH

HD_PWD='E:/Education/Vivado_design_projects/Expr/Expr.runs/impl_1'
cd "$HD_PWD"

HD_LOG=runme.log
/bin/touch $HD_LOG

ISEStep="./ISEWrap.sh"
EAStep()
{
     $ISEStep $HD_LOG "$@" >> $HD_LOG 2>&1
     if [ $? -ne 0 ]
     then
         exit
     fi
}

# pre-commands:
/bin/touch .init_design.begin.rst
EAStep vivado -log expr_plain.vdi -applog -m64 -product Vivado -messageDb vivado.pb -mode batch -source expr_plain.tcl -notrace


