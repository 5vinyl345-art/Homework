`timescale 1ns / 1ps

module tb_lock_controller();
//Input signals
  reg        clk;
  reg        rst;
  reg  [3:0] digit_in;
//Output signal
  wire       unlocked_led;

//Localparam declaration
 localparam DIGIT_1 = 4'd5;
 localparam DIGIT_2 = 4'd3;
 localparam DIGIT_3 = 4'd7;
 
// Device under test 
  lock_controller #(
    .DIGIT_1 (DIGIT_1),
    .DIGIT_2 (DIGIT_2), 
    .DIGIT_3 (DIGIT_3)
  ) DUT (
    .clk(clk),
    .rst(rst),
    .digit_in(digit_in),
    .unlocked_led(unlocked_led)
  );
 
// ---- Clock generator ----
  initial clk = 0;
  always #5 clk = ~clk;

// Main test sequence //
  initial begin
    rst = 1'b1; digit_in = 4'd0;
    #18; rst = 1'b0;
  // Right sequence
    digit_in = 4'd5; @(posedge clk); #1;
    digit_in = 4'd3; @(posedge clk); #1;
    digit_in = 4'd7; @(posedge clk); #1;
    $display("unlocked_led status = %d (expected 1)", unlocked_led);
    #18; rst = 1'b1; #18; rst = 1'b0;
  // Wrong sequence
    digit_in = 4'd5; @(posedge clk); #1;
    digit_in = 4'd3; @(posedge clk); #1; 
    digit_in = 4'd6; @(posedge clk); #1;
    $display("unlocked_led status = %d (expected 0)", unlocked_led);
    #20;
    $finish;
  end

endmodule

