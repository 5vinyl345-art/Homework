`timescale 1ns / 1ps

module lock_controller #(
  parameter [3:0] DIGIT_1 = 4'd5,
  parameter [3:0] DIGIT_2 = 4'd3,
  parameter [3:0] DIGIT_3 = 4'd7
 ) (
  input       clk,
  input       rst,
  input [3:0] digit_in,
  output  reg unlocked_led
);

//FSM State declaraion
  localparam [3:0] LOCKED   = 4'b0001;
  localparam [3:0] WAIT_D2  = 4'b0010;
  localparam [3:0] WAIT_D3  = 4'b0100;
  localparam [3:0] UNLOCKED = 4'b1000;

// FSM register declaration
  reg [3:0] state, next_state;

// FSM
  always @(posedge clk or posedge rst) begin
    if (rst) begin
      state <= LOCKED;
    end else begin
      state <= next_state;
    end
  end
  
  always @(*) begin
    next_state = state;
    case (state)
      LOCKED:
        if (digit_in == DIGIT_1) next_state = WAIT_D2;
        else                     next_state = LOCKED;
      WAIT_D2:
        if (digit_in == DIGIT_2) next_state = WAIT_D3;
        else                     next_state = LOCKED;
      WAIT_D3:
        if (digit_in == DIGIT_3 )next_state = UNLOCKED;
        else                     next_state = LOCKED;
      UNLOCKED:
                                 next_state = UNLOCKED;
      default: next_state = LOCKED;
    endcase
  end
 
  always @(*) begin
    unlocked_led = (state == UNLOCKED);
  end
  
endmodule