`timescale 1ns / 1ps

module tb_lock_system_top();

//Input signals
  reg        clk;
  reg        rst;
  reg  [3:0] digit_in_btn;
//Output signal
  wire       unlocked_led;

//Localparam declaration
 localparam DIGIT_1 = 4'd5;
 localparam DIGIT_2 = 4'd3;
 localparam DIGIT_3 = 4'd7;
 localparam DEFAULT_VALUE = 4'hf;

// Device under test 
  lock_system_top DUT (
    .clk          (clk),
    .rst          (rst),
    .digit_in_btn (digit_in_btn),
    .unlocked_led (unlocked_led)
  );

// ---- Clock generator ----
  initial clk = 0;
  always #1 clk = ~clk; // Clock period decreased for test purposes

// Main test sequence //
  initial begin
    rst = 1'b1; digit_in_btn = DEFAULT_VALUE;
    #18 rst = 1'b0;

  // Debounce check
    #50_000 digit_in_btn = 4'd5;
    #50_000 digit_in_btn  = 4'd7;
    #50_000 digit_in_btn  = 4'd6;
  // Right sequence
    #50_000 digit_in_btn = 4'd5;
    #600_000 digit_in_btn = 4'd3;
    #600_000 digit_in_btn = 4'd7;
    #600_000 $display("unlocked_led status = %d (expected 1)", unlocked_led);
    #18 rst = 1'b1; digit_in_btn = DEFAULT_VALUE;
    #18; rst = 1'b0;
  // Wrong sequence
    #600_000 digit_in_btn = 4'd5; @(posedge clk); #1;
    #600_000 digit_in_btn = 4'd3; @(posedge clk); #1; 
    #600_000 digit_in_btn = 4'd6; @(posedge clk); #1;
    #600_000 $display("unlocked_led status = %d (expected 0)", unlocked_led);
    #20;
    $finish;
  end

endmodule


