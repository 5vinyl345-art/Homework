`timescale 1ns / 1ps

module debounce_filter #(
  parameter SYS_CLK_FREQ = 5, // system clock in MHz
  parameter DEBOUNCE_DLY = 50, // debounce delay in ms
  parameter WIDTH        = 4,
  parameter DEFAULT_VALUE = 4'hf
 )(
  input                  clk,
  input                  rst,
  input      [WIDTH-1:0] ext_in,
  output reg [WIDTH-1:0] filtered_out_stb
);

// Debounce CNT parameters calc
  localparam CNT_VALUE = SYS_CLK_FREQ * 1000 * DEBOUNCE_DLY;
  localparam CNT_WIDTH = $clog2(CNT_VALUE);
  localparam [CNT_WIDTH-1:0] CNT_MAX = CNT_VALUE[CNT_WIDTH-1:0] - 1'b1;

// Internal signals declaration
  reg [WIDTH-1:0]     sync_first, sync_second, toggling_reg;
  reg [CNT_WIDTH-1:0] dly_cnt;
  reg                 cnt_en;
  wire                w_toggling_det;    

// Input signals synchronyzation
  always @(posedge clk or posedge rst) begin
    if (rst) begin
      sync_first  <= DEFAULT_VALUE;
      sync_second <= DEFAULT_VALUE;
    end else begin
      sync_first  <= ext_in;
      sync_second <= sync_first;
    end
  end

// Input signals toggling detection logic
  always @(posedge clk or posedge rst) begin
    if (rst) begin
      toggling_reg <= DEFAULT_VALUE;
    end else begin
      toggling_reg <= sync_second;
    end
  end

  assign w_toggling_det = |(sync_second ^ toggling_reg);

// Debounce delay counting
  always @(posedge clk or posedge rst) begin
    if (rst) begin
      dly_cnt <= CNT_MAX;
    end else if (w_toggling_det) begin
      dly_cnt <= CNT_MAX;
    end else if (cnt_en && (dly_cnt != {CNT_WIDTH{1'b0}})) begin
      dly_cnt <= dly_cnt - 1'b1;
    end
  end

  always @(posedge clk or posedge rst) begin
    if (rst) begin
      cnt_en <= 1'b0;
    end else if (w_toggling_det) begin
      cnt_en <= 1'b1;
    end else if (dly_cnt == {CNT_WIDTH{1'b0}}) begin
      cnt_en <= 1'b0;
    end
  end

// Output signal generation
  always @(posedge clk or posedge rst) begin
    if (rst) begin
      filtered_out_stb <= DEFAULT_VALUE;
    end else if (cnt_en && (dly_cnt == {CNT_WIDTH{1'b0}})) begin
      filtered_out_stb <= sync_second;
    end else begin
      filtered_out_stb <= DEFAULT_VALUE;
    end
  end

endmodule
