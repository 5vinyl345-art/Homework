`timescale 1ns / 1ps

module lock_system_top(
  input        clk,
  input        rst,
   input [3:0] digit_in_btn,
  output       unlocked_led
);

// Settings
  localparam [3:0] DIGIT_1       = 4'd5;
  localparam [3:0] DIGIT_2       = 4'd3;
  localparam [3:0] DIGIT_3       = 4'd7;
  localparam [3:0] DEFAULT_VALUE = 4'hf;
  localparam SYS_CLK_FREQ        = 5;     // system clock in MHz
  localparam DEBOUNCE_DLY        = 50;    // debounce delay in ms
  localparam WIDTH               = 4;
  
// Internal signals declaration
  wire [WIDTH-1:0] filtered_out_stb;

  debounce_filter #(
    .SYS_CLK_FREQ  (SYS_CLK_FREQ ),
    .DEBOUNCE_DLY  (DEBOUNCE_DLY ),
    .WIDTH         (WIDTH        ),
    .DEFAULT_VALUE (DEFAULT_VALUE)
  ) u_debounce (
    .clk              (clk             ),
    .rst              (rst             ),
    .ext_in           (digit_in_btn    ),
    .filtered_out_stb (filtered_out_stb)
  );

  lock_controller #(
    .DIGIT_1       (DIGIT_1      ),
    .DIGIT_2       (DIGIT_2      ),
    .DIGIT_3       (DIGIT_3      ),
    .DEFAULT_VALUE (DEFAULT_VALUE)
  ) u_lock_controller (
    .clk          (clk             ),
    .rst          (rst             ),
    .digit_in     (filtered_out_stb),
    .unlocked_led (unlocked_led    )
  );

endmodule