`timescale 1ns / 1ps

module tb_counter();
//Input signals
  reg        clk;
  reg        rst;
  reg        load;
  reg  [3:0] data_in;
  reg        en;
  reg        up_down;
//Output signal
  wire [3:0] count;
  
// Device under test 
  counter DUT(
    .clk     (clk    ),
    .rst     (rst    ),
    .load    (load   ),
    .data_in (data_in),
    .en      (en     ),
    .up_down (up_down),
    .count   (count  )
  );

  // ---- Clock generator ----
  initial clk = 0;
  always #5 clk = ~clk;

  // Validating task
  task automatic check_count(
    input [3:0] expected,
    input [8*21-1:0] name
  );
    begin
      if (count === expected)
        $display("PASS: %s | count=%0d", name, count);
      else
        $display("FAIL: %s | count=%d | expected = %d", name, count, expected);
    end
  endtask

  // Main test sequence //
  initial begin
    rst = 1'b0; load = 1'b0; data_in = 4'd0; en = 1'b0; up_down = 1'b1;
  // LOAD check
    @(posedge clk); #1 rst = 1'b1;
    @(posedge clk); #1 rst = 1'b0; load = 1'b1; data_in = 4'd10;
    @(posedge clk); #1 load = 1'b0;
    check_count ( 4'd10, "LOAD CHECK");
  // Count UP check
    en = 1;
    repeat(3) @(posedge clk); #1;
    check_count ( 4'd13, "COUNT UP");
    repeat(3) @(posedge clk); #1;
    check_count ( 4'd0, "COUNT UP TO ZERO");
  // EN check
    en = 0;
    repeat(2) @(posedge clk); #1;
    check_count ( 4'd0, "KEEP ON ZERO");
  // Count DOWM check
    en = 1; up_down = 1'b0;
    @(posedge clk); #1;
    check_count ( 4'd15, "COUNT DOWN TO FIFTEEN");
  // LOAD check
    load = 1'b1; data_in = 4'd5; up_down = 1'b0;
    @(posedge clk); #1;
    check_count ( 4'd5, "SET FIVE");
    @(posedge clk); #1;
    $finish;
  end

endmodule
